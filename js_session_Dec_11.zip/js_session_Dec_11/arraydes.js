let zoo=["lion","tiger","hippo","elephant"]

let animal1=zoo[0]
let animal2=zoo[1]
console.log(animal1)
console.log(animal2)

const [a1,a2]=zoo

console.log(a1)
console.log(a2)

const [z1,,z3]=zoo
console.log(z1+" "+z3)

//...rest operator

const [anim1,anim2,...rem_animals]=zoo
console.log(anim1)
console.log(anim2)
console.log(rem_animals)

const a=10
//a=20

const names=["jhon","jim","paul"]
names.push("dhoni")
//names=["asd","afas"]//error
console.log(names)

//...spread operator=>spread the values of a collection

namecopy=names
console.log(namecopy)
names.pop()
console.log(namecopy)

console.log(...namecopy)

let copyzoo=[...zoo]
console.log(copyzoo)
zoo.push("rhino")
console.log(copyzoo)

copyzoo=["giraf",...copyzoo,"deer"]
console.log(copyzoo)
