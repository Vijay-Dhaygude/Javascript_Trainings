let msg="hello everyone"
let greet='Good evening!!'
let finalmsg=` ${msg} ${greet} `
//fullname=`${firstname} ${middlename} ${lastname}`
let username="jhon"
let product="mobile"
let loc="chennai"
let email="@jhongmail.com"
console.log(msg)
console.log(greet)
console.log(finalmsg)

let ordermsg=`hello ${username} your order on ${product} 
is placed successfully, it will bw delivered to ${loc}`

console.log(ordermsg)

console.log(msg.toLocaleUpperCase())
console.log(greet.toLowerCase())
console.log("number of chars:"+finalmsg.length)
console.log(finalmsg.trim().length)//remove space in the end and also in the begining
console.log(loc[0])
loc[0]="C"//it will not work. becoz string is immutable.
console.log(email.includes("@")?"valid email":"invalid email")//it will check the availability of given substring
console.log(email.indexOf("@"))//it will return first occurence of given substring
console.log(email.lastIndexOf("o"))//it will return last occurence of given substring
console.log(email.charAt(0))//it will return char at given pos
console.log(email.charCodeAt(0))
console.log(ordermsg.substring(1,4))//it will return substr from startpos to endpos-1
console.log(ordermsg.slice(-5,-1))//it is similar to substring, but it will work with -ve indexing
console.log(ordermsg.split(" ").length)


//chennai

