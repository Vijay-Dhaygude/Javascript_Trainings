import { add } from "arithmeticmodule.js";
import { sub as s } from "./arithmeticmodule";
import randomname from "./arithmeticmodule" //mul function is imported

console.log(add(10,20))
s(30,40)
randomname(30,40)//mul(30,40)