class Person{
    constructor(){
        
    }
    constructor(fname,lname,age,loc)
    {
      this.firstname=fname
      this.lastname=lname
      this.age=age
      this.location=loc
    }
    fullname()
    {
        return this.firstname+" "+this.lastname
    }

}



let p1=new Person("jhon","adam",30,"mumbai")
let p2=new Person("Virat","kholi",35,"mumbai")

console.log(p1)
console.log(p2)
console.log(p1.fullname())
console.log(p2.fullname())

class Employee extends Person{
    constructor(fname,lname,age,loc,sal,exp)
    {
      super()
      this.salary=sal
      this.exp=exp
    }

}

let e1=new Employee("sachin","Tendulkar",45,"mumbai",50000,10)
console.log(e1)
console.log(e1.fullname())

class Customer extends Person{
    constructor(fname,lname,age,loc,cid,ctype)
    {
        super(fname,lname,age,loc)
        this.cid=cid
        this.ctype=ctype
    }
}

let c1=new Customer("dhoni","MS",50,"ranchi","c123","prime")
console.log(c1)
console.log(c1.fullname())