let a
try
{
    //crititcal statements
  console.log("hello world")
  console.log("opening connection with server")
  //console.log(add())
  let num=-1
  if(num<0)
  {
    throw "less than zero"
  }

}
catch(error)
{
    //statements to handle error
    console.log("error in the program:"+error)
}
finally{
    //closing activities
    console.log("Finally is executed")
    console.log("close connection with server")
}
