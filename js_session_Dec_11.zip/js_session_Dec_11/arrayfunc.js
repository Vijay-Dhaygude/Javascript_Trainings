let products=["mobile","pendrive","mouse","pen","monitor","laptop"]

console.log(products.find((p)=>p.startsWith("l")))//find will identify the first occurence of given cond
console.log(products.filter((p)=>p.startsWith('m')))// filter will find all occurence of given cond
console.log(products.map((p)=>p.toUpperCase()))//map will transform the array items 
console.log(products)
products.forEach((p)=>console.log(p.substring(0,3)))// forEach will execute the given code for each item.


