console.log("Hello world ")
document.write("<h1>JS demo</h1>")
alert("Hi user welcome to the js Session")
let isconfirm=confirm("are you want to proceed?")
//ok-true
//cancel-false
console.log(isconfirm)
let username=prompt("Enter user name")
//enter value-ok->value
//no value-ok->empty string
//cancel->null
console.log("Welcome:"+username)





