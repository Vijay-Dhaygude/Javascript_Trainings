//var-function scope-redecalre-reassign
//let-block scope-no redeclare-reassign
//const-block scope-no redeclare-no reassign

var x=20
let a=10
const b=30

function display()
{
    //function
    var msg="Hello"
    let letmsg="Hello"
    const org="ACCENTURE"
    const pi=22/7

    {
   //block 
   var msg="Good morning"
   var msg="GOOD MORNING"//redeclare
   msg="MORNING"//reassign

   let letmsg="Good morning"
   //let letmsg="GOOD MORNING"//redecalre//error
   letmsg="MORNING"//reassign

   const org="Accenture Pvt Ltd"
   //const org="XYZ pvt ltd"//redeclare//error
   //org="xyz pvt ltd"//reassign//error

   console.log("msg:"+msg)
   console.log("letmsg:"+letmsg)
   console.log("org:"+org)
    }
 console.log("-----outside block---")
 console.log("msg:"+msg)
 console.log("letmsg:"+letmsg)
 console.log("org:"+org)
  
}

display()