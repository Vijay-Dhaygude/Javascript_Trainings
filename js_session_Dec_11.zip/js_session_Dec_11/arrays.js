let numbers=[1,2,3,8,2,4]
let alpa=["a",'b',"asda","c","d"]
let aplhanum=[2,3,45,'a',"bsdf"]
let mixedarray=[1,2,4,true,"as",["asd",12,3],null,undefined]

let products=["mobile","pendrive","watch","tv","bag"]
console.log(products[3])
products[2]="monitor"
console.log(products)

//array functions
products.push("mouse")//it will append the given item
console.log(products)
products.pop()// it will remove last item
console.log(products)
products.unshift("keyboard")//it will add the item in the begining
console.log(products)
products.shift()//it will remove the item from the begining
console.log(products)
products.splice(2,2)// it will remove items from a given pos
console.log(products)
products.splice(2,0,"charger")//it will add the item at the given pos
console.log(products)
console.log("no of products:"+products.length)//return no of items
console.log(products.includes("mobile"))// return true if item is available
console.log(products.indexOf("laptop"))//return the pos of given item
console.log(products.join("**"))//it will join the array items with given chars & return a string