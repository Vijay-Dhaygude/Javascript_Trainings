let product={
    name:"mobile",
    brandname:"samsung",
    price:40000,
    rating:4,
    detail:function(){
        return `${this.name}- ${this.brandname} Rs:${this.price}`
    }
}

console.log(product)
console.log(product.name)
console.log(product["brandname"])

product.price=50000
product.rating=product.rating-1
console.log(product)
console.log(product.detail())

let product2={
    name:"laptop",
    brand:"dell",
    price:50000
}

//constructor function

function Product(name,brand,price,rating)
{
    this.pname=name
    this.pbrand=brand
    this.pprice=price
    this.prating=rating
}

let p1=new Product("pendrive","hp",5000,4)
let p2=new Product("mouse","logitech",500,3)

console.log(p1)
console.log(p2)

//prototype
Product.prototype.detail=function(){  return `${this.pname}- ${this.pbrand} Rs:${this.pprice}`}

console.log(p1)
console.log(p2)
console.log(p1.detail())
console.log(p2.detail())
