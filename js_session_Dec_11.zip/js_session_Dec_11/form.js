function handlechange()
{
    console.log("handle change called")
}

function handleEmail(){
    document.getElementById("email").style.backgroundColor="green"

}

function handleblur(e)
{
    e.style.backgroundColor="aqua"
   
}

function handlesubmit(){
 let pw=document.getElementById("pw").value
 let cpw=document.getElementById("cpw").value
 //document.getElementsByTagName("input")[0]
 //document.getElementsByClassName("uname")

 console.log(pw)
 console.log(cpw)
 if(pw!=cpw)
 {
    document.getElementById("pw").focus()
    return false
 }
 else
 {
    return true
 }

}