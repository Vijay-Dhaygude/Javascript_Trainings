let product={
    name:"mobile",
    brandname:"samsung",
    price:40000,
    rating:4,
    supplier:"xyz",
    detail:function(){
        return `${this.name}- ${this.brandname} Rs:${this.price}`
    }
}

function getproduct(){
    return {
        p_name:"laptop",
        brand:"dell"
    }
}

let pname=product.name
let brand=product.brandname

const {brandname,name,supplier="amazon"}=product

console.log(name)
console.log(brandname)
console.log(supplier)

const {p_name}=getproduct()
console.log(p_name)
//...spread operator to spread the values of object
let copyproduct={...product,purchasecount:100}
console.log(copyproduct)