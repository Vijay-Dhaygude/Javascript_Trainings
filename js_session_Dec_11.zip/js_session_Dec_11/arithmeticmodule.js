export function add(num1,num2)
{
    return num1+num2
}
export function sub(num1,num2)
{
    return num1-num2
}
function mul(num1,num2)
{
    return num1*num2
}



export default mul
export {add,sub}