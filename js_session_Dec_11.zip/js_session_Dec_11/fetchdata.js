function fetchdata(){
    fetch("https://jsonplaceholder.typicode.com/users").
    then((data)=>data.json()).
    then((finaldata)=>console.log(finaldata[0])).
    catch((error)=>console.log(error))

}

fetchdata()