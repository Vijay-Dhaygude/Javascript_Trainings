let a=10//number
console.log(typeof a)
a="Hello"//string
console.log(typeof a)
a=10.5//number
console.log(typeof a)
let msg='hi every one'//string
console.log(typeof msg)
let islogin=true//boolean
console.log(typeof islogin)
let info //undefined
console.log(typeof info)
let x=null//object
console.log(typeof x)
let y=""
console.log(typeof y)

