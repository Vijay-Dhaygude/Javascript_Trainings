let height=parseInt(prompt("Enter the height"))
let weight=parseInt(prompt("Enter the weight"))
let country=prompt("Enter the country name")
let bmi = weight/(height*height)
console.log(bmi)

if(bmi<=18.5)
{

document.write("Under weight")
}

else if(bmi>18.5&&bmi<24.9)

{
document.write("Normal")
}
/*
else if(cond){}
.....
*/

else
{
    document.write("Over weight")
}


document.write("<br>")
switch(country){
    case "india":
        document.write("Welcome indian")
        break
    case "usa":
        document.write("Welcome american")
        break
    case "germany":
        document.write("welcome german")
        break
    default:
        document.write("Welcome human")
}
