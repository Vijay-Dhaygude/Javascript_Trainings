//function statement
function display()
{
    console.log("Hello world")
}

display()
display()

function add(num1,num2)
{
    return num1+num2
}

console.log(add(10,20))
console.log(add(20,20))

//function expression

let sub=function(num1,num2)
{
    return num1-num2
}
let mul=function(num1,num2){return num1*num2}
console.log(sub(30,20))

function calculate(a,b,operator) //a=30,b=10, operator=(num1,num2)=>num1%num2
{
    return operator(a,b)//operator(30,10)//30%10
}
//callback function is a function which canbe passed as param to another function
console.log(calculate(10,20,sub))//sub is a callback function
console.log(calculate(10,20,mul))//mul is callback
console.log(calculate(10,20,function(num1,num2){return num1/num2}))

//arrow function
//function(num1,num2){return num1*num2}


let mod=(num1,num2)=>num1%num2
/*
(num1,num2)=>{
    let res=num1*num2
    return res
}

*/

console.log(calculate(30,7,mod))//mod is callback
console.log(calculate(40,50,(num1,num2)=>num1+num2))



