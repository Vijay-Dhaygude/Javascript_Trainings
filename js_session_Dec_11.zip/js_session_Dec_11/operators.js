let num1=parseInt(prompt("Enter number1"))
let num2=Number(prompt("Enter number2"))
console.log("add:"+(num1+num2))
console.log("sub:"+(num1-num2))
console.log("mul:"+(num1*num2))
console.log("div:"+(num1/num2))
console.log("greater:"+(num1>num2))
console.log("lesser:"+(num1<num2))
console.log("equal:"+(num1==num2))
console.log("not equal:"+(num1!=num2))

//strict equality
let a=10
let b=10
console.log("a==b"+(a==b))//it will check for value //true
console.log("a===b"+(a===b))//it will check for both type & value //false



