let display=function(){
    console.log("hello world")
}//func def
/*
....

*/

display()//func call
//IIFE=immediately invoked function expression

(function(){
    console.log("hello world")
})();