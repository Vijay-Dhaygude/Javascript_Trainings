let p2=new Promise(function(resolve,reject){
    setTimeout(()=>{
    console.log("getting data from server")
    resolve("data recieved")
    //reject("network failure")
    },5000)
    }
    )

    async function processingdata()
    {
      await p2 //control will wait for the promises to be resolved\
      //await p3
      //await p4
      console.log("process data")

    }

    processingdata()