console.log("********")
//setTimeout(()=>console.log("getting data from server"),5000)//1
//console.log("process the data")//2


//let count=-1
/*let p1=new Promise(function(resolve,reject){
  if(count>=0)
  {
   resolve("the count is greater than or equal to zero")
  }
  else
  {
    reject("the count is less than zer0")
  }

})


console.log(p1)*/

let p2=new Promise(function(resolve,reject){
setTimeout(()=>{
console.log("getting data from server")
resolve("data recieved")
//reject("network failure")
},5000)
}
)
p2.then((msg)=>{console.log(msg)
console.log("process the data")
return "task2"
}).then((msg)=>{console.log(msg)
return "task3"
}).then((msg)=>{console.log(msg)})
.catch((error)=>console.log(error))