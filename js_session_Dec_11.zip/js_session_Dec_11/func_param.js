function discount(price,tax,discount=0.05)
{
    let finalprice=price-(price*discount)+(price*tax)
    return finalprice
}

console.log(discount(100,0.13,0.1))
console.log(discount(100,0.13))

function add(...nums)
{
 let total=0
 nums.forEach((n)=>total=total+n)
 console.log("sum:"+total)
}

add(10)
add(10,20)
add(10,20,30)
add(10,20,30,40)